type 'a t = {
  mutable front : 'a list;
  mutable rear : 'a list;
  mutable size : int;
}

let create () = { front = []; rear = []; size = 0 }

let is_empty q = q.size = 0

let push x q =
  if is_empty q then q.front <- [ x ] else q.rear <- x :: q.rear;
  q.size <- q.size + 1

exception Empty

let pop q =
  let x =
    match q.front with
    | [] -> raise Empty
    | [ x ] ->
        q.front <- List.rev q.rear;
        q.rear <- [];
        x
    | x :: f ->
        q.front <- f;
        x
  in
  q.size <- q.size - 1;
  x
