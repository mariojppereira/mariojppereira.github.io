(*@ open Set *)
(*@ open Seq *)

(*@ lemma seq_cons: forall s1 s2: 'a seq, x: 'a.
      s1 = cons x s2 -> forall i. 0 <= i < Seq.length s2 -> s1[i+1] = s2[i] *)

module type HASHABLE = sig
  type t
  val [@logic] hash : t -> int

  val equal : t -> t -> bool
  (*@ b = equal t1 t2
        ensures b <-> t1 = t2 *)
end

(** Signature merging {!ORDERED_TYPE} and {!HASHABLE}. *)
module type COMPARABLE = sig
  type t
  val [@logic] compare : t -> t -> int
  (*@ axiom pre_order_compare: is_pre_order compare*)

  val [@logic] hash : t -> int

  val equal : t -> t -> bool
  (*@ b = equal t1 t2
        ensures b <-> t1 = t2 *)
end

(*@ lemma equal_hashes_HASHABLE: forall t1, t2 . t1 = t2 -> HASHABLE.hash t1 = HASHABLE.hash t2 *)
(*@ lemma equal_hashes_COMPARABLE: forall t1, t2 . t1 = t2 -> COMPARABLE.hash t1 = COMPARABLE.hash t2 *)

module Check
    (G :
     sig
       module V : COMPARABLE
       type gt
       (*@ model dom: V.t fset
             model suc: V.t -> V.t fset
             with x invariant forall v1, v2. Fset.mem v1 x.dom ->
                      Fset.mem v2 (x.suc v1) -> Fset.mem v2 x.dom *)

       val [@logic] succ : gt -> V.t -> V.t list
       (*@ l = succ g v
             requires Fset.mem v g.dom
             ensures forall v'. List.mem v' l <-> Fset.mem v' (g.suc v) *)

     end) =
struct

  module HV = Hashtbl.Make(G.V)

  (*@ predicate edge (v1 : G.V.t) (v2 : G.V.t) (g : G.gt) =
        Fset.mem v2 (g.G.suc v1) *)

  (*@ predicate distinct (s : G.V.t seq) =
        forall i j. 0 <= i < length s -> 0 <= j < length s ->
              i <> j -> s[i] <> s[j] *)

  (*@ predicate disjoint ( sq : G.V.t Queue.t ) ( st : unit HV.t ) =
        forall v1. Seq.mem v1 sq.Queue.view -> not (Fset.mem v1 st.HV.dom) /\ forall v2. Fset.mem v2 st.HV.dom -> not (Seq.mem v2 sq.Queue.view) *)

  (*@ predicate is_path (v1 : G.V.t) (l : G.V.t seq) (v2 : G.V.t) (g : G.gt) =
        let len = Seq.length l in
        if len = 0 then v1 = v2 else
          edge v1 l[0] g && l[len - 1] = v2 && Fset.mem v1 g.G.dom &&
        forall i : int. 0 <= i < len - 1 -> edge l[i] l[i+1] g *)

  (*@ predicate has_path (v1 v2 : G.V.t) (g : G.gt) =
        exists p. is_path v1 p v2 g *)

  (*@ lemma path_suc : forall v1, v2, v3 : G.V.t, g : G.gt.
        Fset.mem v1 g.G.dom -> has_path v1 v2 g -> edge v2 v3 g ->
        has_path v1 v3 g *)

  (*@ lemma edge_path : forall v1, v2, v3 : G.V.t, g : G.gt.
        edge v1 v2 g /\ edge v2 v3 g -> is_path v1 (Seq.singleton v2) v3 g -> has_path v1 v3 g*)

  (*@ lemma self_path : forall v1 : G.V.t, g: G.gt.
        is_path v1 (Seq.empty) v1 g -> has_path v1 v1 g *)

  let [@ghost] [@logic] rec intermediate_value_func p (u : G.V.t) (v : G.V.t) ( s : G.V.t list) ( g : G.gt)  =
    match s with
    | [] -> assert false
    | x :: xs -> if not (p x) then (u, x, [], xs) else
        let (u', v', s1, s2) = intermediate_value_func p x v xs g in (u', v', x::s1, s2)
  (*@ (u', v', s1, s2 ) = intermediate_value_func p u v s g
        requires p u
        requires not (p v)
        requires is_path u (Seq.of_list s) v g
        variant s
        ensures p u'
        ensures not (p v')
        ensures is_path u s1 u' g
        ensures is_path v' s2 v g
        ensures edge u' v' g *)

  (*@ lemma intermediate_value : forall p, u, v, s, g.
    p u -> not p v -> is_path u s v g ->
    exists u' v' s1 s2. p u' /\ not p v' /\ is_path u s1 u' g /\ is_path v' s2 v g /\ edge u' v' g *)

  let check_path graph v1 v2 =
    let marked = HV.create 97 in
    let [@ghost] visited = HV.create 97 in
    let q = Queue.create () in
    let rec loop () =
      if Queue.is_empty q then begin
        false
      end else begin
        let v = Queue.pop q in
        if G.V.compare v v2 = 0 then true
        else begin
          HV.add visited v () ;
          let sucs = G.succ graph v in
          let rec iter_succ ( prefix [@ghost] ) = function
            | [] -> ()
            | v' :: r -> if not (HV.mem marked v' ) then begin HV.add marked v' () ; Queue.add v' q end ; iter_succ (prefix @ [v']) r
            (*@ iter_succ p l
                  requires forall v'. List.mem v' l -> edge v v' graph

                  variant l

                  ensures not (Fset.mem v2 visited.HV.dom)
                  requires not (Fset.mem v2 visited.HV.dom)

                  requires sucs = p @ l
                  ensures sucs = p @ l

                   ensures distinct q.Queue.view
                   requires distinct q.Queue.view

                  ensures forall v'. Fset.mem v' (old marked).HV.dom -> Fset.mem v' marked.HV.dom
                  ensures forall v'. Fset.mem v' (old visited).HV.dom -> Fset.mem v' visited.HV.dom
                  ensures forall v'. Seq.mem v' (old q).Queue.view -> Seq.mem v' q.Queue.view

                  requires forall v'. Fset.mem v' visited.HV.dom /\ v' <> v -> forall s. edge v' s graph -> Fset.mem s marked.HV.dom
                  ensures forall v'. Fset.mem v' visited.HV.dom -> forall s. edge v' s graph -> Fset.mem s marked.HV.dom

                  ensures has_path v1 v2 graph -> exists w. Seq.mem w q.Queue.view /\ has_path w v2 graph


                   ensures Fset.subset marked.HV.dom graph.G.dom
                   requires Fset.subset marked.HV.dom graph.G.dom

                   ensures forall v'. Fset.mem v' marked.HV.dom  -> Fset.mem v' visited.HV.dom \/ Seq.mem v' q.Queue.view
                   requires forall v'. Fset.mem v' marked.HV.dom  -> Fset.mem v' visited.HV.dom \/ Seq.mem v' q.Queue.view

                  ensures forall v'. Fset.mem v' marked.HV.dom  -> has_path v1 v' graph
                  requires forall v'. Fset.mem v' marked.HV.dom -> has_path v1 v' graph

                   ensures forall v'. List.mem v' l -> Fset.mem v' marked.HV.dom
                   requires forall v'. List.mem v' p -> Fset.mem v' marked.HV.dom

                   requires disjoint q visited
                   ensures disjoint q visited

                   ensures forall v'. Fset.mem v' visited.HV.dom -> Fset.mem v' marked.HV.dom
                   requires forall v'. Fset.mem v' visited.HV.dom -> Fset.mem v' marked.HV.dom

                   ensures forall v'. Seq.mem v' q.Queue.view   -> Fset.mem v' marked.HV.dom
                   requires forall v'. Seq.mem v' q.Queue.view   -> Fset.mem v' marked.HV.dom

                  ensures Fset.mem v1 marked.HV.dom
                  requires Fset.mem v1 marked.HV.dom

                  ensures Fset.mem v1 visited.HV.dom
                  requires Fset.mem v1 visited.HV.dom
             *)
          in
          iter_succ [] sucs ;
          loop ()
        end
      end
      (*@ b = loop ()
            requires has_path v1 v2 graph -> exists w. Seq.mem w q.Queue.view /\ has_path w v2 graph
            ensures b <-> has_path v1 v2 graph
            raises  Queue.Empty -> false

            variant Fset.cardinal graph.G.dom - Fset.cardinal visited.HV.dom, Seq.length q.Queue.view

             requires distinct q.Queue.view
             ensures distinct q.Queue.view

            requires forall v'. Fset.mem v' marked.HV.dom ->  Fset.mem v' visited.HV.dom \/ Seq.mem v' q.Queue.view
            ensures forall v'. Fset.mem v' marked.HV.dom /\ v' <> v2 ->  Fset.mem v' visited.HV.dom \/ Seq.mem v' q.Queue.view

             requires Fset.subset visited.HV.dom graph.G.dom
             ensures Fset.subset visited.HV.dom graph.G.dom

             requires Fset.subset marked.HV.dom graph.G.dom
             ensures Fset.subset marked.HV.dom graph.G.dom

            requires forall v. Fset.mem v marked.HV.dom -> has_path v1 v graph
            ensures forall v. Fset.mem v marked.HV.dom -> has_path v1 v graph

            requires not (Fset.mem v2 visited.HV.dom)
            ensures not (Fset.mem v2 visited.HV.dom)

             requires disjoint q visited
             ensures disjoint q visited

             requires forall v. Fset.mem v visited.HV.dom -> Fset.mem v marked.HV.dom
             ensures forall v. Fset.mem v visited.HV.dom -> Fset.mem v marked.HV.dom

             requires forall v. Fset.mem v visited.HV.dom -> forall s. edge v s graph -> Fset.mem s marked.HV.dom
             ensures forall v. Fset.mem v visited.HV.dom -> forall s. edge v s graph -> Fset.mem s marked.HV.dom

             requires forall v. Seq.mem v q.Queue.view -> Fset.mem v marked.HV.dom
             ensures forall v. Seq.mem v q.Queue.view -> Fset.mem v marked.HV.dom

            requires Seq.mem v1 q.Queue.view -> q.Queue.view == Seq.singleton v1

            requires Fset.mem v1 marked.HV.dom
            ensures Fset.mem v1 marked.HV.dom
      *)
    in
    HV.add marked v1 () ;
    Queue.add v1 q;
    loop ()
    (*@ b = check_path graph v1 v2
          requires Fset.mem v1 graph.G.dom
          ensures b <-> has_path v1 v2 graph *)

end

(*************************************************************************************************************************

   Altered version of the original path.ml. Table *visited* became ghost and a new table was added called *marked*.
   No repeated vertices are added to the queue now, as they are checked before being added and not on pop. Ghost
   table *visited* serves to know which vertices are marked, but have already left the queue.

 ***************************************************************************************************************************)
