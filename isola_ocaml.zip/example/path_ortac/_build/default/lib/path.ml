type vertex = int

type t = {
  mutable dom: vertex list;
  mutable suc: (vertex * vertex list) list;
}

let empty () = {
  dom = [];
  suc = [];
}

let add_vertex v g =
  g.dom <- v :: g.dom

let rec assoc v1 = function
  | [] -> []
  | (x, l) :: rs -> if v1 = x then l else assoc v1 rs

let add_edge v1 v2 g =
  g.dom <- v1 :: v2 :: g.dom;
  g.suc <- (v1, v2 :: assoc v1 g.suc) :: g.suc

let check_path q v1 v2 g =
  let marked = Hashtbl.create 97 in
  let rec loop () =
    let v = Queue.pop q in
    if compare v v2 = 0 then true
    else begin
      Hashtbl.add marked v () ;
      let sucs = assoc v g.suc in
      let rec iter_succ = function
        | [] -> ()
        | v' :: r ->
          if not (Hashtbl.mem marked v') then begin
            Hashtbl.add marked v' ();
            Queue.add v' q end ;
          iter_succ r
      in
      iter_succ sucs ;
      loop ()
    end
  in
  Hashtbl.add marked v1 () ;
  Queue.add v1 q;
  loop ()

(*************************************************************************************************************************

   Altered version of the original path.ml. Table *visited* became ghost and a new table was added called *marked*.
   No repeated vertices are added to the queue now, as they are checked before being added and not on pop. Ghost
   table *visited* serves to know which vertices are marked, but have already left the queue.

 ***************************************************************************************************************************)
